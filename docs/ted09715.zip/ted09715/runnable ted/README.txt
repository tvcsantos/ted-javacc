When running into problems with ted always check if you have the latest java version installed:
http://www.java.com.

For further information how to run and use ted, please read our online documentation:
http://www.ted.nu/documentation/

You can find existing bugs and feature requests in our bugtracker: 
http://www.ted.nu/bugs/

If you need support or want to report a bug or feature request: go to our support forum: 
http://www.ted.nu/forum/

Enjoy ted!

Roel & Joost
ted Developers