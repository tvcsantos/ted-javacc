package ted;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * TED: Torrent Episode Downloader (2005 - 2010)
 * 
 * The urltranslater translates urls from the rss items to actual download urls
 * where ted can download the torrent from
 * 
 * @author Roel
 * @author Joost
 *
 * ted License:
 * This file is part of ted. ted and all of it's parts are licensed
 * under GNU General Public License (GPL) version 2.0
 * 
 * for more details see: http://en.wikipedia.org/wiki/GNU_General_Public_License
 *
 */

public class UrlTranslator 
{	
	public UrlTranslator()
	{		
	}

	public String translateUrl(String url, String sTitle)
	{
		String torrentUrl = url;
		if(		url.indexOf("bt-chat.com") != -1 ||
				url.indexOf("thepiratebay.org") != -1 || 
				url.indexOf("mrtwig.net") != -1 ||
				url.indexOf("torrentlocomotive.com") != -1 ||
				url.indexOf("sdnett.org") != -1 ||
				url.indexOf("torrentleechc.org") != -1 ||
				url.indexOf("iptorrents.com") != -1 ||
				url.indexOf("zoink.it") != -1 ||
				url.indexOf("digitaldistractions.org") != -1 ||
				url.indexOf("tvtorrents.com") != -1 ||
				url.indexOf("torrentbytes.net") != -1)
		{
			// do nothing, url already in right format
		}
		else if (url.indexOf("btjunkie.org") != -1)
		{
			// url in feed: http://btjunkie.org/torrent/this-american-life-106-hdtv-xvid-kyr-avi/2908c5164f4f566eb149c60c83d4896edbf3012943ed%26id%3D
			// has to be http://btjunkie.org/torrent/this-american-life-106-hdtv-xvid-kyr-avi/2908c5164f4f566eb149c60c83d4896edbf3012943ed%26id%3D/download.torrent
			// get id argument and paste it behind url
			torrentUrl += "/download.torrent";
		}
		else if (url.indexOf("sharetv.org") != -1)
		{
			// url in the feed: http://sharetv.org/torrent/103163
			// has to be: http://sharetv.org/get/103163
			torrentUrl = torrentUrl.replace("info", "get");
			torrentUrl = torrentUrl.replace("torrent", "get");
		}	
		else if (url.indexOf("torrentreactor.net") != -1 || url.indexOf("Torrentreactor.Net") != -1)
		{
			// make torrentreactor download url
			// url in rss: http://torrentreactor.net/view.php?id=5307280
			// has to be: http://dl.torrentreactor.net/download.php?id=5307280&name=Prison.Break.S02E09.PROPER.HDTV.XviD-XOR.VOST-FRENCH-PM3
			String[] tempUrl;
			tempUrl = torrentUrl.split("id=");
			
			// filter [Series TV/Show Showname] from name
			String[] tempName;
			tempName = sTitle.split("] ");
			
			try 
			{
				torrentUrl = "http://dl.torrentreactor.net/download.php?name=" + URLEncoder.encode(tempName[1], "UTF-8") + "&id=" + tempUrl[1];
			}
			catch (UnsupportedEncodingException e)
			{
				torrentUrl = null;
			}
		}
		else if (url.indexOf("bushtorrent.com") != -1 || url.indexOf("Bushtorrent.com") != -1)
		{
			// same as torrentreactor
			
			// make bushtorrent download url
			// url in rss: http://bushtorrent.com/view.php?id=5307280
			// has to be: http://dl.bushtorrent.com/download.php?id=645941&name=Prison.Break.S02E09.PROPER.HDTV.XviD-XOR.VOST-FRENCH-PM3
			String[] tempUrl;
			tempUrl = torrentUrl.split("id=");
			
			// filter [Series TV/Show Showname] from name
			String[] tempName;
			tempName = sTitle.split("] ");
			
			try 
			{
				torrentUrl = "http://dl.bushtorrent.com/download.php?name=" + URLEncoder.encode(tempName[1], "UTF-8") + "&id=" + tempUrl[1];
			}
			catch (UnsupportedEncodingException e)
			{
				torrentUrl = null;
			}
		}
		else if(url.indexOf("isohunt.com") != -1)
		{	
			// url in rss = http://isohunt.com/torrent_details/14578531/lost (where lost is the query used to make rss feed)
			// has to be: http://isohunt.com/download/14578531/lost
			torrentUrl = torrentUrl.replace("torrent_details", "download");
			torrentUrl = torrentUrl.replace(" ", "+");
			
			// or url in rss = http://isohunt.com/release/14578531/lost (where lost is the query used to make rss feed)
			// points to release page, not useful
			if (url.indexOf("release") != -1)
			{
				torrentUrl = null;
			}			
		}
		else if(url.indexOf("mininova") != -1)
		{
			// url in rss http://www.mininova.org/tor/239805
			// has to be: http://www.mininova.org/get/239805
			torrentUrl = torrentUrl.replace("tor", "get");
		}
		else if(url.indexOf("seedler.org") != -1)
		{
			// url in rss: http://www.seedler.org/en/html/info/499236
			// has to be: http://www.seedler.org/download.x?id=499236
			torrentUrl = torrentUrl.replace("en/html/info/", "download.x?id=");
		}
		else if(url.indexOf("xtvi.com") != -1)
		{
			// url in rss: http://www.xtvi.com/torrents.php?mode=details&id=54933&.torrent
			// has to be: http://www.xtvi.com/torrents.php?mode=gettorrent&id=54933
			torrentUrl = torrentUrl.replace("details", "gettorrent");	
		}
		else if (url.indexOf("torrentportal.com") != -1)
		{
			// url in rss: http://www.torrentportal.com/details/955139/Law.and.Order.S17E16.HDTV.XviD-NoTV.torrent
			// has to be: http://www.torrentportal.com/download/955139/Law.and.Order.S17E16.HDTV.XviD-NoTV.torrent
			torrentUrl = torrentUrl.replace("details", "download");
		}
		else if (url.indexOf("fenopy.com") != -1)
		{
			// url in rss: http://fenopy.com/torrent/Fringe+S02E06+VOSTFR+Gillop+avi/MjY5OTY0OQ
			// has to be: http://fenopy.com/torrent/Fringe_S02E06_VOSTFR_Gillop_avi/MjY5OTY0OQ==/download.torrent
			// get name parameter from url
			torrentUrl += "==/download.torrent";
		}
		else if (url.indexOf("vertor.com") != -1)
		{
			// url in rss: http://www.vertor.com/torrents/464745/Heroes-S1
			// has to be: http://www.vertor.com/index.php?mod=download&id=464745
			torrentUrl = torrentUrl.replace("torrents/", "index.php?mod=download&id=");
			
			String[] temp;
			temp = torrentUrl.split("/");
			torrentUrl = torrentUrl.replace("/" + temp[4], "");
		}
		/*else if (url.indexOf("kickasstorrents.com") != -1)
		{
			// url in rss: http://www.kickasstorrents.com/surviving-the-dustbowl-american-experience-pbs-the-1930s-t3253037.html
			// has to be: http://www.kickasstorrents.com/torrents/surviving-the-dustbowl-american-experience-pbs-the-1930s-10931360.torrent
		}*/
		else if (url.indexOf("torrentzap.com") != -1)
		{
			// url in rss: http://www.torrentzap.com/torrent/831190/PBS+The+National+Parks+Americas+Best+Idea+6of6+The+Morning+of+Creation+XviD+AC3+MVGroup+org+avi
			// has to be: http://dl.torrentzap.com/download/1/831190
			torrentUrl = torrentUrl.replace("www.torrentzap.com/torrent", "dl.torrentzap.com/download/6");
			
			String[] name;
			name = torrentUrl.split("/");
			torrentUrl = torrentUrl.replace("/" + name[6], "");
		}
		else if (torrentUrl.endsWith(".torrent"))
		{
			// do nothing, string ends on ".torrent", we assume that is a correct torrent file
		}
		else
		{
			torrentUrl = null;
		}
		
		return torrentUrl;
	}
}
