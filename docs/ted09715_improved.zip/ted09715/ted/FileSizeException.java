package ted;

public class FileSizeException extends Exception 
{
	
	public double size = 0;

	/**
	 * 
	 */
	private static final long serialVersionUID = 4141890502899907377L;

}
