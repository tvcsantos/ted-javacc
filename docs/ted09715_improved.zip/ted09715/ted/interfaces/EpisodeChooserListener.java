package ted.interfaces;

public interface EpisodeChooserListener
{
	public void episodeSelectionChanged();
	public void doubleClickOnEpisodeList();

}
