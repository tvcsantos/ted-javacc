package ted.interfaces;

public interface PanelSwitcher 
{
	public void showPanel(String command);

}
