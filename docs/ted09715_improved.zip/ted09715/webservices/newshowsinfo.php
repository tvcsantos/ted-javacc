<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>ted update information</title>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#FF7010" vlink="#FF7010" alink="#FF7010" leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0">
<center>
<table width="95%" border="0" cellpadding="5">
  <tr>
    <td width="100" align="left"><a href="http://www.ted.nu/"><img src="http://www.ted.nu/img/header_logo.png" alt="ted logo" width="98" height="85" border="0"></a></td>
    <td align="left" valign="middle"><p><font face="Arial, Helvetica, sans-serif" size="+1">v37</font></p>
    <p><font face="Arial, Helvetica, sans-serif" size="-1">released: 04-10-2009</font></p></td>
  </tr>
  <tr>
    <td colspan="2">
        <font face="Arial, Helvetica, sans-serif">
		<p>Changed default RSS feeds. Ted now uses EZRSS, BTJunkie, isoHunt and Mininova.</p>
		<strong><font color="#225A8D" size="+1">added</font></strong>
		</p>
		<ul><li>FlashForward
		</li><li>Cleveland show
		</li><li>Stargate Universe
		</li><li>Three Rivers
		</li><li>The Vampire Diaries
		</li><li>Glee
		</li><li>Melrose Place
		</li><li>The Jay Leno Show
		</li><li>The Good Wife
		</li><li>Cougar Town
		</li><li>Modern Family
		</li></ul>
		<strong><font color="#225A8D" size="+1">removed</font></strong>
		</p>
		<ul><li>The Tonight Show with Jay Leno

		</li></ul>
		<p><br />
		</p>

        </font>
        
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="+1" color="#FF7010"><a href="http://www.ted.nu/forum/viewforum.php?f=6">request a show</a></font></p>
</center>
</body>
</html>
