<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>ted update information</title>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#FF7010" vlink="#FF7010" alink="#FF7010" leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0">
<center>
<table width="95%" border="0" cellpadding="5">
  <tr>
    <td width="100" align="left"><a href="http://www.ted.nu/"><img src="http://www.ted.nu/img/header_logo.png" alt="ted logo" width="98" height="85" border="0"></a></td>
    <td align="left" valign="middle"><p><font face="Arial, Helvetica, sans-serif" size="+1">new in version 0.9715</font></p>
    <p><font face="Arial, Helvetica, sans-serif" size="-1">released: 03-02-2010</font></p></td>
  </tr>
  <tr>
    <td colspan="2">
    	<font face="Arial, Helvetica, sans-serif" size="-1">
		<p>
		<strong><font color="#225A8D" size="+1" face="Arial, Helvetica, sans-serif">IMPORTANT UPDATE</font></strong>
		</p>
		</p>
		<ul>
			<li><b>This new version of ted is a mandatory upgrade for all users!</b><br> Please update as soon as possible as ted will otherwise stop working on 
february the 10th. After this date our webservice, which is responsible for downloading the torrents, will no longer be functional.
			<li>We hope to release a new version of ted with new features in the upcoming weeks.
		</ul>
		<p><br />
		 </font>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="+1" color="#FF7010"><a href="http://www.ted.nu/download.php">download</a></font></p>
</center>
</body>
</html>
